# WP-API plugin Extension

A [WP-API](http://wp-api.org/) extension that allows get user by username and email

* `/wp-json/users/user/<username>`
* `/wp-json/users/email/<email>`

## Installation
Download plugin, upload from Worpress plugin panel setting and install.

